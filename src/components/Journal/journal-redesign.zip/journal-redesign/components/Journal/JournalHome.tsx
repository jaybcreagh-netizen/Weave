/**
 * JournalHome
 * 
 * Redesigned journal browser with:
 * - Memory surfacing (anniversaries, patterns, throwbacks)
 * - Tab navigation: All | By Friend | Calendar
 * - Search capability
 * - Quick access to new entry flows
 * 
 * This is the main entry point for the Journal feature.
 */

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  FlatList,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import Animated, {
  FadeIn,
  FadeInDown,
  FadeInUp,
} from 'react-native-reanimated';
import {
  Search,
  Plus,
  BookOpen,
  Users,
  Calendar,
  Sparkles,
  ChevronRight,
  Clock,
  Edit3,
  MessageCircle,
  Lightbulb,
  X,
} from 'lucide-react-native';
import { useTheme } from '@/shared/hooks/useTheme';
import { database } from '@/db';
import JournalEntry from '@/db/models/JournalEntry';
import WeeklyReflection from '@/db/models/WeeklyReflection';
import FriendModel from '@/db/models/Friend';
import { Q } from '@nozbe/watermelondb';
import * as Haptics from 'expo-haptics';

import {
  getMemories,
  getFriendsForBrowsing,
  searchEntries,
  Memory,
} from '@/modules/journal/services/journal-context-engine';

// ============================================================================
// TYPES
// ============================================================================

type Tab = 'all' | 'friend' | 'calendar';

interface JournalHomeProps {
  onNewEntry: (mode: 'quick' | 'guided') => void;
  onEntryPress: (entry: JournalEntry | WeeklyReflection) => void;
  onFriendArcPress: (friendId: string) => void;
  onMemoryAction: (memory: Memory) => void;
}

interface FriendWithEntries {
  friend: FriendModel;
  entryCount: number;
  lastEntryDate: Date | null;
  recentActivityIndicator: 'high' | 'medium' | 'low';
}

// ============================================================================
// COMPONENT
// ============================================================================

export function JournalHome({
  onNewEntry,
  onEntryPress,
  onFriendArcPress,
  onMemoryAction,
}: JournalHomeProps) {
  const { colors } = useTheme();

  // State
  const [activeTab, setActiveTab] = useState<Tab>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Data
  const [entries, setEntries] = useState<(JournalEntry | WeeklyReflection)[]>([]);
  const [friendsWithEntries, setFriendsWithEntries] = useState<FriendWithEntries[]>([]);
  const [memories, setMemories] = useState<Memory[]>([]);

  // ============================================================================
  // DATA LOADING
  // ============================================================================

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      await Promise.all([
        loadEntries(),
        loadFriends(),
        loadMemories(),
      ]);
    } catch (error) {
      console.error('[JournalHome] Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadEntries = async () => {
    const [journalEntries, reflections] = await Promise.all([
      database
        .get<JournalEntry>('journal_entries')
        .query(Q.sortBy('entry_date', Q.desc))
        .fetch(),
      database
        .get<WeeklyReflection>('weekly_reflections')
        .query(Q.sortBy('week_start_date', Q.desc), Q.take(20))
        .fetch(),
    ]);

    // Combine and sort by date
    const combined = [
      ...journalEntries,
      ...reflections,
    ].sort((a, b) => {
      const dateA = 'entryDate' in a ? a.entryDate : a.weekStartDate;
      const dateB = 'entryDate' in b ? b.entryDate : b.weekStartDate;
      return dateB - dateA;
    });

    setEntries(combined);
  };

  const loadFriends = async () => {
    const friends = await getFriendsForBrowsing();
    setFriendsWithEntries(friends);
  };

  const loadMemories = async () => {
    const surfacedMemories = await getMemories(3);
    setMemories(surfacedMemories);
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  // ============================================================================
  // SEARCH
  // ============================================================================

  const handleSearch = useCallback(async (query: string) => {
    setSearchQuery(query);

    if (query.trim().length < 2) {
      await loadEntries();
      return;
    }

    const results = await searchEntries(query, { type: 'all' });
    setEntries(results);
  }, []);

  const clearSearch = () => {
    setSearchQuery('');
    setShowSearch(false);
    loadEntries();
  };

  // ============================================================================
  // RENDER HELPERS
  // ============================================================================

  const formatEntryDate = (date: Date): string => {
    const now = new Date();
    const entryDate = new Date(date);

    // Same day
    if (entryDate.toDateString() === now.toDateString()) {
      return 'Today';
    }

    // Yesterday
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    if (entryDate.toDateString() === yesterday.toDateString()) {
      return 'Yesterday';
    }

    // This week
    const weekAgo = new Date(now);
    weekAgo.setDate(weekAgo.getDate() - 7);
    if (entryDate > weekAgo) {
      return entryDate.toLocaleDateString('en-GB', { weekday: 'long' });
    }

    // Older
    return entryDate.toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: entryDate.getFullYear() !== now.getFullYear() ? 'numeric' : undefined,
    });
  };

  const getEntryPreview = (entry: JournalEntry | WeeklyReflection): string => {
    if ('content' in entry) {
      return (entry.content || '').slice(0, 100);
    }
    return (entry.gratitudeText || '').slice(0, 100);
  };

  const getEntryTitle = (entry: JournalEntry | WeeklyReflection): string => {
    if ('title' in entry && entry.title) {
      return entry.title;
    }
    if ('weekStartDate' in entry) {
      return 'Weekly Reflection';
    }
    return 'Journal Entry';
  };

  const isWeeklyReflection = (entry: JournalEntry | WeeklyReflection): boolean => {
    return 'weekStartDate' in entry;
  };

  const renderActivityIndicator = (level: 'high' | 'medium' | 'low') => {
    const dots = level === 'high' ? 3 : level === 'medium' ? 2 : 1;
    return (
      <View className="flex-row gap-0.5">
        {[...Array(3)].map((_, i) => (
          <View
            key={i}
            className="w-1.5 h-1.5 rounded-full"
            style={{
              backgroundColor: i < dots ? colors.primary : colors.border,
            }}
          />
        ))}
      </View>
    );
  };

  // ============================================================================
  // SECTION RENDERS
  // ============================================================================

  const renderMemoryCard = () => {
    if (memories.length === 0) return null;

    const memory = memories[0];

    return (
      <Animated.View entering={FadeInDown.delay(100).duration(400)} className="px-5 mb-4">
        <TouchableOpacity
          onPress={() => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            onMemoryAction(memory);
          }}
          className="p-4 rounded-2xl"
          style={{
            backgroundColor: colors.primary + '10',
            borderWidth: 1,
            borderColor: colors.primary + '30',
          }}
          activeOpacity={0.7}
        >
          <View className="flex-row items-center gap-2 mb-2">
            <Lightbulb size={16} color={colors.primary} />
            <Text
              className="text-xs uppercase tracking-wide"
              style={{ color: colors.primary, fontFamily: 'Inter_600SemiBold' }}
            >
              Memory
            </Text>
          </View>

          <Text
            className="text-base mb-2"
            style={{ color: colors.foreground, fontFamily: 'Lora_500Medium' }}
          >
            {memory.title}
          </Text>

          <Text
            className="text-sm mb-3"
            style={{ color: colors['muted-foreground'], fontFamily: 'Inter_400Regular' }}
          >
            {memory.description}
          </Text>

          <View className="flex-row items-center gap-1">
            <Text
              className="text-sm"
              style={{ color: colors.primary, fontFamily: 'Inter_500Medium' }}
            >
              {memory.actionLabel}
            </Text>
            <ChevronRight size={16} color={colors.primary} />
          </View>
        </TouchableOpacity>
      </Animated.View>
    );
  };

  const renderTabs = () => (
    <View className="flex-row px-5 mb-4 gap-2">
      {[
        { id: 'all' as Tab, label: 'All', icon: BookOpen },
        { id: 'friend' as Tab, label: 'By Friend', icon: Users },
        { id: 'calendar' as Tab, label: 'Calendar', icon: Calendar },
      ].map((tab) => {
        const isActive = activeTab === tab.id;
        const IconComponent = tab.icon;

        return (
          <TouchableOpacity
            key={tab.id}
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              setActiveTab(tab.id);
            }}
            className="flex-row items-center gap-1.5 px-4 py-2 rounded-full"
            style={{
              backgroundColor: isActive ? colors.primary : colors.muted,
            }}
            activeOpacity={0.7}
          >
            <IconComponent
              size={16}
              color={isActive ? colors['primary-foreground'] : colors['muted-foreground']}
            />
            <Text
              className="text-sm"
              style={{
                color: isActive ? colors['primary-foreground'] : colors['muted-foreground'],
                fontFamily: 'Inter_500Medium',
              }}
            >
              {tab.label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );

  const renderAllTab = () => (
    <View className="flex-1">
      {entries.length === 0 ? (
        <View className="flex-1 items-center justify-center px-8 py-16">
          <BookOpen size={40} color={colors['muted-foreground']} />
          <Text
            className="text-lg mt-4 text-center"
            style={{ color: colors.foreground, fontFamily: 'Lora_500Medium' }}
          >
            No entries yet
          </Text>
          <Text
            className="text-sm mt-2 text-center"
            style={{ color: colors['muted-foreground'], fontFamily: 'Inter_400Regular' }}
          >
            Start documenting your friendships
          </Text>
        </View>
      ) : (
        <ScrollView showsVerticalScrollIndicator={false} className="flex-1">
          {entries.map((entry, index) => {
            const date = 'entryDate' in entry 
              ? new Date(entry.entryDate) 
              : new Date(entry.weekStartDate);
            const isReflection = isWeeklyReflection(entry);

            return (
              <Animated.View
                key={entry.id}
                entering={FadeInDown.delay(100 + index * 30).duration(300)}
              >
                <TouchableOpacity
                  onPress={() => {
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                    onEntryPress(entry);
                  }}
                  className="mx-5 mb-3 p-4 rounded-2xl"
                  style={{
                    backgroundColor: colors.card,
                    borderWidth: 1,
                    borderColor: colors.border,
                  }}
                  activeOpacity={0.7}
                >
                  {/* Header */}
                  <View className="flex-row items-center gap-2 mb-2">
                    {isReflection ? (
                      <Clock size={14} color={colors.primary} />
                    ) : (
                      <Edit3 size={14} color={colors.primary} />
                    )}
                    <Text
                      className="text-xs flex-1"
                      style={{ color: colors['muted-foreground'], fontFamily: 'Inter_400Regular' }}
                    >
                      {formatEntryDate(date)}
                    </Text>
                    {isReflection && (
                      <View
                        className="px-2 py-0.5 rounded-full"
                        style={{ backgroundColor: colors.muted }}
                      >
                        <Text
                          className="text-xs"
                          style={{ color: colors['muted-foreground'], fontFamily: 'Inter_400Regular' }}
                        >
                          Weekly
                        </Text>
                      </View>
                    )}
                  </View>

                  {/* Title */}
                  <Text
                    className="text-base mb-1"
                    style={{ color: colors.foreground, fontFamily: 'Inter_500Medium' }}
                  >
                    {getEntryTitle(entry)}
                  </Text>

                  {/* Preview */}
                  <Text
                    className="text-sm"
                    style={{ color: colors['muted-foreground'], fontFamily: 'Inter_400Regular' }}
                    numberOfLines={2}
                  >
                    {getEntryPreview(entry)}...
                  </Text>

                  {/* Friend Tags (for journal entries) */}
                  {'friendTags' in entry && entry.friendTags && (
                    <FriendTags
                      friendIds={JSON.parse(entry.friendTags || '[]')}
                      colors={colors}
                    />
                  )}
                </TouchableOpacity>
              </Animated.View>
            );
          })}

          {/* Bottom padding */}
          <View className="h-24" />
        </ScrollView>
      )}
    </View>
  );

  const renderFriendTab = () => (
    <ScrollView showsVerticalScrollIndicator={false} className="flex-1">
      <View className="px-5">
        {friendsWithEntries.length === 0 ? (
          <View className="items-center justify-center py-16">
            <Users size={40} color={colors['muted-foreground']} />
            <Text
              className="text-lg mt-4 text-center"
              style={{ color: colors.foreground, fontFamily: 'Lora_500Medium' }}
            >
              No friendships documented yet
            </Text>
            <Text
              className="text-sm mt-2 text-center"
              style={{ color: colors['muted-foreground'], fontFamily: 'Inter_400Regular' }}
            >
              Tag friends in your entries to see them here
            </Text>
          </View>
        ) : (
          <>
            <Text
              className="text-xs uppercase tracking-wide mb-4"
              style={{ color: colors['muted-foreground'], fontFamily: 'Inter_600SemiBold' }}
            >
              Your Friendships
            </Text>

            {friendsWithEntries.map((item, index) => (
              <Animated.View
                key={item.friend.id}
                entering={FadeInDown.delay(100 + index * 30).duration(300)}
              >
                <TouchableOpacity
                  onPress={() => {
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                    onFriendArcPress(item.friend.id);
                  }}
                  className="mb-3 p-4 rounded-2xl flex-row items-center"
                  style={{
                    backgroundColor: colors.card,
                    borderWidth: 1,
                    borderColor: colors.border,
                  }}
                  activeOpacity={0.7}
                >
                  {/* Avatar */}
                  <View
                    className="w-12 h-12 rounded-full items-center justify-center mr-3"
                    style={{ backgroundColor: colors.muted }}
                  >
                    <Text
                      className="text-lg"
                      style={{ color: colors.foreground, fontFamily: 'Inter_600SemiBold' }}
                    >
                      {item.friend.name.charAt(0).toUpperCase()}
                    </Text>
                  </View>

                  {/* Info */}
                  <View className="flex-1">
                    <Text
                      className="text-base"
                      style={{ color: colors.foreground, fontFamily: 'Inter_500Medium' }}
                    >
                      {item.friend.name}
                    </Text>
                    <View className="flex-row items-center gap-2 mt-0.5">
                      <Text
                        className="text-sm"
                        style={{ color: colors['muted-foreground'], fontFamily: 'Inter_400Regular' }}
                      >
                        {item.entryCount} {item.entryCount === 1 ? 'entry' : 'entries'}
                      </Text>
                      {item.lastEntryDate && (
                        <>
                          <Text style={{ color: colors.border }}>·</Text>
                          <Text
                            className="text-sm"
                            style={{ color: colors['muted-foreground'], fontFamily: 'Inter_400Regular' }}
                          >
                            Last: {formatEntryDate(item.lastEntryDate)}
                          </Text>
                        </>
                      )}
                    </View>
                  </View>

                  {/* Activity indicator */}
                  <View className="items-center">
                    {renderActivityIndicator(item.recentActivityIndicator)}
                  </View>

                  <ChevronRight size={20} color={colors['muted-foreground']} className="ml-2" />
                </TouchableOpacity>
              </Animated.View>
            ))}
          </>
        )}
      </View>

      {/* Bottom padding */}
      <View className="h-24" />
    </ScrollView>
  );

  const renderCalendarTab = () => (
    <View className="flex-1 items-center justify-center px-8">
      <Calendar size={40} color={colors['muted-foreground']} />
      <Text
        className="text-lg mt-4 text-center"
        style={{ color: colors.foreground, fontFamily: 'Lora_500Medium' }}
      >
        Calendar View
      </Text>
      <Text
        className="text-sm mt-2 text-center"
        style={{ color: colors['muted-foreground'], fontFamily: 'Inter_400Regular' }}
      >
        Coming soon — browse entries by date
      </Text>
    </View>
  );

  // ============================================================================
  // MAIN RENDER
  // ============================================================================

  if (loading) {
    return (
      <View className="flex-1 items-center justify-center" style={{ backgroundColor: colors.background }}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <View className="flex-1" style={{ backgroundColor: colors.background }}>
      {/* Header */}
      <View className="px-5 pt-4 pb-3">
        <View className="flex-row items-center justify-between mb-4">
          <Text
            className="text-2xl"
            style={{ color: colors.foreground, fontFamily: 'Lora_700Bold' }}
          >
            Journal
          </Text>

          <View className="flex-row items-center gap-2">
            <TouchableOpacity
              onPress={() => setShowSearch(!showSearch)}
              className="w-10 h-10 rounded-full items-center justify-center"
              style={{ backgroundColor: showSearch ? colors.primary + '20' : colors.muted }}
            >
              <Search size={20} color={showSearch ? colors.primary : colors['muted-foreground']} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Search Bar */}
        {showSearch && (
          <Animated.View entering={FadeInUp.duration(200)} className="mb-4">
            <View
              className="flex-row items-center px-4 py-3 rounded-xl"
              style={{ backgroundColor: colors.muted }}
            >
              <Search size={18} color={colors['muted-foreground']} />
              <TextInput
                value={searchQuery}
                onChangeText={handleSearch}
                placeholder="Search entries..."
                placeholderTextColor={colors['muted-foreground']}
                className="flex-1 ml-3 text-base"
                style={{ color: colors.foreground, fontFamily: 'Inter_400Regular' }}
                autoFocus
              />
              {searchQuery.length > 0 && (
                <TouchableOpacity onPress={clearSearch}>
                  <X size={18} color={colors['muted-foreground']} />
                </TouchableOpacity>
              )}
            </View>
          </Animated.View>
        )}
      </View>

      {/* Memory Card */}
      {!showSearch && renderMemoryCard()}

      {/* Tabs */}
      {!showSearch && renderTabs()}

      {/* Content */}
      {activeTab === 'all' && renderAllTab()}
      {activeTab === 'friend' && renderFriendTab()}
      {activeTab === 'calendar' && renderCalendarTab()}

      {/* Floating Action Button */}
      <View className="absolute bottom-6 right-5">
        <NewEntryFAB onPress={onNewEntry} colors={colors} />
      </View>
    </View>
  );
}

// ============================================================================
// SUB-COMPONENTS
// ============================================================================

interface FriendTagsProps {
  friendIds: string[];
  colors: Record<string, string>;
}

function FriendTags({ friendIds, colors }: FriendTagsProps) {
  const [friends, setFriends] = useState<FriendModel[]>([]);

  useEffect(() => {
    if (friendIds.length === 0) return;

    database
      .get<FriendModel>('friends')
      .query(Q.where('id', Q.oneOf(friendIds)))
      .fetch()
      .then(setFriends);
  }, [friendIds]);

  if (friends.length === 0) return null;

  return (
    <View className="flex-row flex-wrap gap-1.5 mt-2">
      {friends.slice(0, 3).map((friend) => (
        <View
          key={friend.id}
          className="flex-row items-center gap-1 px-2 py-1 rounded-full"
          style={{ backgroundColor: colors.primary + '15' }}
        >
          <Users size={10} color={colors.primary} />
          <Text
            className="text-xs"
            style={{ color: colors.primary, fontFamily: 'Inter_500Medium' }}
          >
            {friend.name}
          </Text>
        </View>
      ))}
      {friends.length > 3 && (
        <View
          className="px-2 py-1 rounded-full"
          style={{ backgroundColor: colors.muted }}
        >
          <Text
            className="text-xs"
            style={{ color: colors['muted-foreground'], fontFamily: 'Inter_400Regular' }}
          >
            +{friends.length - 3}
          </Text>
        </View>
      )}
    </View>
  );
}

interface NewEntryFABProps {
  onPress: (mode: 'quick' | 'guided') => void;
  colors: Record<string, string>;
}

function NewEntryFAB({ onPress, colors }: NewEntryFABProps) {
  const [expanded, setExpanded] = useState(false);

  const handlePress = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setExpanded(!expanded);
  };

  const handleQuick = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setExpanded(false);
    onPress('quick');
  };

  const handleGuided = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setExpanded(false);
    onPress('guided');
  };

  return (
    <View>
      {/* Expanded Options */}
      {expanded && (
        <Animated.View entering={FadeInUp.duration(200)} className="mb-3">
          {/* Quick Capture */}
          <TouchableOpacity
            onPress={handleQuick}
            className="flex-row items-center gap-3 px-4 py-3 rounded-2xl mb-2"
            style={{
              backgroundColor: colors.card,
              borderWidth: 1,
              borderColor: colors.border,
              shadowColor: '#000',
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.1,
              shadowRadius: 4,
              elevation: 3,
            }}
            activeOpacity={0.8}
          >
            <Edit3 size={18} color={colors.primary} />
            <View>
              <Text
                className="text-sm"
                style={{ color: colors.foreground, fontFamily: 'Inter_500Medium' }}
              >
                Quick Note
              </Text>
              <Text
                className="text-xs"
                style={{ color: colors['muted-foreground'], fontFamily: 'Inter_400Regular' }}
              >
                Capture a thought fast
              </Text>
            </View>
          </TouchableOpacity>

          {/* Guided Reflection */}
          <TouchableOpacity
            onPress={handleGuided}
            className="flex-row items-center gap-3 px-4 py-3 rounded-2xl"
            style={{
              backgroundColor: colors.card,
              borderWidth: 1,
              borderColor: colors.border,
              shadowColor: '#000',
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.1,
              shadowRadius: 4,
              elevation: 3,
            }}
            activeOpacity={0.8}
          >
            <Sparkles size={18} color={colors.primary} />
            <View>
              <Text
                className="text-sm"
                style={{ color: colors.foreground, fontFamily: 'Inter_500Medium' }}
              >
                Guided Reflection
              </Text>
              <Text
                className="text-xs"
                style={{ color: colors['muted-foreground'], fontFamily: 'Inter_400Regular' }}
              >
                Write with prompts
              </Text>
            </View>
          </TouchableOpacity>
        </Animated.View>
      )}

      {/* Main FAB */}
      <TouchableOpacity
        onPress={handlePress}
        className="w-14 h-14 rounded-full items-center justify-center"
        style={{
          backgroundColor: colors.primary,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 4 },
          shadowOpacity: 0.2,
          shadowRadius: 8,
          elevation: 6,
          transform: [{ rotate: expanded ? '45deg' : '0deg' }],
        }}
        activeOpacity={0.9}
      >
        <Plus size={24} color={colors['primary-foreground']} />
      </TouchableOpacity>
    </View>
  );
}

export default JournalHome;
