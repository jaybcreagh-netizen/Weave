# Journal Feature Redesign - Integration Guide

## Overview

This redesign transforms the journal from a simple note-taking feature into a **living memory system** that knows your friendships and helps you understand them better.

### Three Core Modes

1. **Quick Capture** - Get the thought down NOW (zero friction)
2. **Guided Reflection** - Deeper writing with context and prompts
3. **Memory Browser** - See friendship arcs and patterns over time

---

## File Structure

```
src/
├── modules/
│   └── journal/
│       ├── services/
│       │   ├── journal-context-engine.ts   ← Core brain - context, memories, arcs
│       │   └── journal-prompts.ts          ← Contextual prompt generation
│       └── index.ts
│
├── components/
│   └── Journal/
│       ├── JournalHome.tsx                 ← Main browser with tabs + memory
│       ├── QuickCaptureSheet.tsx           ← Mode 1: minimal entry
│       ├── GuidedReflectionModal.tsx       ← Mode 2: full flow
│       ├── FriendshipArcView.tsx           ← Timeline per friend
│       ├── WeaveReflectPrompt.tsx          ← Bridge from weave logger
│       └── index.ts
```

---

## Installation

### 1. Copy Services

Copy `modules/journal/` to your `src/modules/` directory.

### 2. Copy Components

Copy `components/Journal/` to your `src/components/` directory.

### 3. Update Module Exports

In your main modules index, add:

```typescript
export * from './journal';
```

### 4. Database Model Updates

The JournalEntry model needs these fields (add if missing):

```typescript
// In your JournalEntry model
@field('is_draft') isDraft?: boolean;
@field('prompt_used') promptUsed?: string;
@field('linked_weave_id') linkedWeaveId?: string;
```

Add a migration if needed:

```typescript
{
  toVersion: X,
  steps: [
    addColumns({
      table: 'journal_entries',
      columns: [
        { name: 'is_draft', type: 'boolean', isOptional: true },
        { name: 'prompt_used', type: 'string', isOptional: true },
        { name: 'linked_weave_id', type: 'string', isOptional: true },
      ],
    }),
  ],
}
```

---

## Usage Examples

### Basic Setup in App Navigator

```tsx
import {
  JournalHome,
  QuickCaptureSheet,
  GuidedReflectionModal,
  FriendshipArcView,
} from '@/components/Journal';

function JournalScreen() {
  const [showQuickCapture, setShowQuickCapture] = useState(false);
  const [showGuided, setShowGuided] = useState(false);
  const [selectedFriendId, setSelectedFriendId] = useState<string | null>(null);

  // If viewing a friend's arc
  if (selectedFriendId) {
    return (
      <FriendshipArcView
        friendId={selectedFriendId}
        onBack={() => setSelectedFriendId(null)}
        onEntryPress={(id, type) => {
          // Navigate to entry detail
        }}
        onWriteAbout={(friendId, friendName) => {
          setSelectedFriendId(null);
          setShowGuided(true);
          // Pass friend context to guided modal
        }}
      />
    );
  }

  return (
    <>
      <JournalHome
        onNewEntry={(mode) => {
          if (mode === 'quick') setShowQuickCapture(true);
          else setShowGuided(true);
        }}
        onEntryPress={(entry) => {
          // Navigate to entry detail
        }}
        onFriendArcPress={(friendId) => {
          setSelectedFriendId(friendId);
        }}
        onMemoryAction={(memory) => {
          // Handle memory action (read entry, write about friend, etc.)
        }}
      />

      <QuickCaptureSheet
        visible={showQuickCapture}
        onClose={() => setShowQuickCapture(false)}
        onExpandToFull={(text, friendIds) => {
          setShowQuickCapture(false);
          setShowGuided(true);
          // Pass text/friends to guided modal
        }}
      />

      <GuidedReflectionModal
        visible={showGuided}
        onClose={() => setShowGuided(false)}
        onSave={(entry) => {
          console.log('Saved:', entry);
        }}
      />
    </>
  );
}
```

### Integrating WeaveReflectPrompt in Weave Logger

```tsx
import { 
  WeaveReflectPrompt, 
  useWeaveReflectPrompt 
} from '@/components/Journal';

function WeaveLoggerScreen() {
  const { 
    showPrompt, 
    checkAndShowPrompt, 
    hidePrompt, 
    promptInteraction, 
    promptFriends 
  } = useWeaveReflectPrompt();

  const handleWeaveComplete = async (interaction, friends) => {
    // After saving weave...
    
    // Check if we should prompt for reflection
    const shouldShow = await checkAndShowPrompt(interaction, friends);
    
    if (!shouldShow) {
      // Close logger normally
      navigation.goBack();
    }
    // If shouldShow, the prompt will appear
  };

  return (
    <View>
      {/* Your weave logger UI */}
      
      <WeaveReflectPrompt
        visible={showPrompt}
        interaction={promptInteraction}
        friends={promptFriends}
        onReflect={() => {
          hidePrompt();
          navigation.navigate('Journal', { 
            mode: 'guided',
            weaveId: promptInteraction?.id 
          });
        }}
        onDismiss={() => {
          hidePrompt();
          navigation.goBack();
        }}
      />
    </View>
  );
}
```

### Opening Journal from Friend Profile

```tsx
// In FriendProfileScreen
<TouchableOpacity
  onPress={() => navigation.navigate('Journal', { 
    mode: 'friend-arc',
    friendId: friend.id 
  })}
>
  <Text>{entryCount} journal entries</Text>
</TouchableOpacity>
```

---

## Key Services

### JournalContextEngine

The brain of the journal. Provides:

```typescript
// Get meaningful weaves worth reflecting on
const weaves = await getRecentMeaningfulWeaves(5, 72);

// Get context for a specific friend
const context = await getFriendContext(friendId);

// Surface memories (anniversaries, patterns)
const memories = await getMemories(3);

// Get friendship arc (timeline of entries)
const arc = await getFriendshipArc(friendId);

// Get friends sorted by journal engagement
const friends = await getFriendsForBrowsing();

// Search entries
const results = await searchEntries('career', { friendId: '...' });
```

### JournalPrompts

Generates contextual prompts:

```typescript
// For a specific weave
const prompts = generateJournalPrompts({ type: 'weave', weave });

// For a friend
const prompts = generateJournalPrompts({ type: 'friend', friendContext });

// General prompts
const prompts = generateJournalPrompts({ type: 'general' });

// Get single best prompt
const prompt = getBestPrompt(context);
```

---

## Migration from Existing Journal

### Files to Deprecate

After testing the new components:

| Old Component | Replaced By |
|--------------|-------------|
| `JournalEntryModal` | `QuickCaptureSheet` + `GuidedReflectionModal` |
| `ReflectionJourneyModal` | `JournalHome` |
| `ReflectionJourneyContent` | `FriendshipArcView` |

### Key Differences

1. **Two entry modes** instead of one overloaded modal
2. **Context-aware prompts** instead of generic textarea
3. **Friend-centric browsing** instead of flat chronological list
4. **Memory surfacing** (anniversaries, patterns) - new feature
5. **Weave → Journal bridge** - new integration point

---

## Future AI Integration Points

The architecture is designed for easy LLM handoff:

### 1. Prompt Generation

Replace rule-based prompts in `journal-prompts.ts`:

```typescript
// Current (rule-based)
export function generateJournalPrompts(context: PromptContext): JournalPrompt[] {
  // ... rule-based logic
}

// Future (LLM-powered)
export async function generateJournalPrompts(context: PromptContext): Promise<JournalPrompt[]> {
  const response = await fetch('/api/journal/prompts', {
    method: 'POST',
    body: JSON.stringify({
      context,
      previousEntries: await getRecentEntryExcerpts(),
      userWritingStyle: await getDetectedWritingStyle(),
    }),
  });
  return response.json();
}
```

### 2. Memory Surfacing

Enhance pattern detection in `journal-context-engine.ts`:

```typescript
// Current: keyword matching
function detectThemes(text: string): string[] {
  // Simple keyword detection
}

// Future: LLM analysis
async function detectThemes(text: string): Promise<string[]> {
  const response = await llm.analyze({
    task: 'theme_extraction',
    text,
    friendshipContext: await getFriendshipContext(),
  });
  return response.themes;
}
```

### 3. Writing Assistance

Add to GuidedReflectionModal:

```typescript
// "Help me articulate this" button
const handleAssist = async () => {
  const suggestion = await llm.assist({
    currentText: text,
    prompt: selectedPrompt,
    context: selectedContext,
    request: 'expand',  // or 'clarify', 'continue', etc.
  });
  setText(text + ' ' + suggestion);
};
```

### 4. Conversational Journaling

Future mode: chat-based reflection:

```typescript
// Instead of text field, a conversation:
const messages = [
  { role: 'assistant', content: 'You logged a deep conversation with Emma. What's staying with you?' },
  { role: 'user', content: 'We talked about her job offer. She's torn.' },
  { role: 'assistant', content: 'It sounds like you were in a supportive role. How did that feel?' },
];
```

---

## Customization

### Prompt Templates

Edit `WEAVE_PROMPTS`, `FRIEND_PROMPTS`, and `GENERAL_PROMPTS` in `journal-prompts.ts` to customize questions.

### Meaningfulness Thresholds

Adjust when the "Reflect deeper" prompt appears:

```typescript
// In WeaveReflectPrompt.tsx
const MEANINGFUL_WEAVE_THRESHOLDS = {
  noteLength: 20,           // Minimum note length
  highVibe: ['FullMoon', 'WaxingGibbous'],
  deepCategories: ['deep-talk', 'heart-to-heart', 'support'],
  longDurations: ['Extended', 'Long'],
};
```

### Theme Keywords

Add/modify theme detection:

```typescript
// In journal-context-engine.ts
const THEME_KEYWORDS: Record<string, string[]> = {
  career: ['job', 'work', 'career', ...],
  growth: ['grow', 'change', 'learn', ...],
  // Add your own themes
};
```

---

## Testing Checklist

- [ ] Quick Capture saves correctly as draft
- [ ] Guided Reflection shows meaningful weaves
- [ ] Friend context loads correctly
- [ ] Prompts generate based on context type
- [ ] Friend tags persist on entries
- [ ] Friendship arc timeline renders correctly
- [ ] Memory surfacing finds anniversaries
- [ ] Search works across entries and reflections
- [ ] WeaveReflectPrompt respects rate limiting
- [ ] All animations feel smooth

---

## Questions?

This redesign is comprehensive but modular — you can adopt pieces incrementally:

1. **Phase 1**: QuickCaptureSheet + WeaveReflectPrompt (quick wins)
2. **Phase 2**: GuidedReflectionModal (depth)
3. **Phase 3**: JournalHome + FriendshipArcView (browsing)
4. **Phase 4**: AI integration (future)
